import{_ as e}from"./DlAUqK2U.js";import{j as r,k as c}from"./BDM2wHLL.js";const o={};function t(n,s){return r(),c("div")}const f=e(o,[["render",t]]);export{f as default};
