import{c as i}from"./7Y2qv051.js";const o="/additional-links",a={GetList(t){return i.get(`${o}`,{params:{sort:"orderCode:ASC",...t}})}};export{a as A};
