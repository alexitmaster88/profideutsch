import{ae as t}from"./BDM2wHLL.js";const d=t((e,o)=>{console.log("AUTH MIDDLEWARE RUN",o),e.path});export{d as default};
