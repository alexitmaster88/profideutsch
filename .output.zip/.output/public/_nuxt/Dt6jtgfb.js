import{_ as e}from"./DlAUqK2U.js";import{E as t}from"./BDM2wHLL.js";const o={};function n(r,s){return t(r.$slots,"default")}const f=e(o,[["render",n]]);export{f as default};
