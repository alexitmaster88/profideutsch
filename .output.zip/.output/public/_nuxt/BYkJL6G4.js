import{c as e}from"./7Y2qv051.js";const r="/pages",s={GetList(t){return e.get(`${r}`,{params:{sort:"createdAt:DESC",...t}})},Get(t){return e.get(`${r}/findSlug/${t}`)}};export{s as P};
