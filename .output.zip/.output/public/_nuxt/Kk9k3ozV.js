import"./BDM2wHLL.js";const o=""+new URL("loader-video.BK60hwGP.mp4",import.meta.url).href;export{o as v};
