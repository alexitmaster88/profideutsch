const __vite__fileDeps=["./entry.Cqpv9oGE.css"],__vite__mapDeps=i=>i.map(i=>__vite__fileDeps[i]);
import{h as s,r as n,S as a,a8 as t,j as o,k as p,z as m,x as l,J as i,ab as _}from"./BDM2wHLL.js";const d={className:`prose\r
		max-w-none\r
            marker:prose-ol:text-primary\r
            prose-bullets:bg-primary\r
            marker:prose-ul:text-primary\r
			prose-a:font-semibold\r
			prose-a:text-primary\r
            prose-img:rounded-lg prose-img:shadow-lg\r
			 prose-pre:bg-blue-900 \r
			 prose-pre:text-pink-200 \r
			 hover:prose-pre:font-bold \r
			 prose-headings:text-gray-900 \r
			 sm:prose-base md:prose-base lg:prose-slate\r
			 `},b=s({inheritAttrs:!1,__name:"MarkdownCustom",setup(u){const r=n(null);return a(()=>{r.value=t(()=>_(()=>import("./BwNvYs08.js").then(e=>e.v),__vite__mapDeps([0]),import.meta.url))}),(e,c)=>(o(),p("div",d,[(o(),m(i(r.value),l(e.$attrs,{class:"overflow-auto"}),null,16))]))}});export{b as _};
