import"./BDM2wHLL.js";const L="uz",t=L;export{t as L};
