import{c as e}from"./7Y2qv051.js";const r="/videos",o={GetList(t){return e.get(`${r}`,{params:{sort:"createdAt:DESC",...t}})},Get(t){return e.get(`${r}/${t}`)}};export{o as V};
