<template>
	<slot />
</template>
