export type NeedChamberServiceGroupListDto = {
    id: number
    code: string
    orderCode: string
    shortName: string
    fullName: string
    stateId: number
    state: string
}