<template>
	<div class="cursor-pointer md:p-6 p-4 group overflow-hidden items-stretch bg-white shadow-sm rounded-lg hover:shadow-md transition duration-300 ease-in-out">
		<slot></slot>
	</div>
</template>
