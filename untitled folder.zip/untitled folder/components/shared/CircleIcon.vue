<template>
	<div
		class="w-12 h-12 border border-white relative justify-center items-center rounded-full hover:bg-cyan-400 transition-all duration-300 ease-out inline-flex"
	>
		<slot></slot>
	</div>
</template>

<script setup lang="ts"></script>
